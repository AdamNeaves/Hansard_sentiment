# main control file

import NLP
import Speech_Parser_BS
import sentiment_analyser
import Manual_Tagger

