# COMPLETELY FAKE SEARCH MOCKUP THAT DOES NOTHING
print("What would you like to do?")
print("1: Search via Member of Parliament Name \n"
      "2: Search via Topic\n"
      "3: Input Sentence for sentiment extraction\n"
      "4: Retrain Sentiment Analysis Model(!)\n"
      "Q: Quit Program")
input("Choice:")
print("--SEARCH VIA MEMBER--")
print("Member Name: Alan Jones")
print("    Searching...")
print("2 topics found for Alan Jones")
print("    TOPIC --------------------------------------------------- AVERAGE SENTIMENT")
print("    1: Trading Schemes Bill                                 -      POSITIVE")
print("    2: Gender Identity (Registration and Civil Status) Bill -      NEGATIVE")
print("Options:\n"
      "1: Select Topic\n"
      "2: Search New Member\n"
      "Q: Return to previous Menu")
input("Choice:")
print("Showing Speech from topic 1: Trading Schemes Bill:")
print("Pyramid selling and multi-level marketing have become great and expanding businesses. Such marketing exercises\n"
      "involve more than people trading from their own homes; it has come to my notice that professional people such\n"
      "as doctors, surgeons and others who see and relate to people at different levels are also now encouraging and\n"
      "indulging in multi-level marketing and pyramid selling. Patients come to see doctors to get fitter and healthier,\n"
      "and in that relationship they may be encouraged to buy water filters, air cleaners or filters and other things,\n"
      "in the surgery. That is a remarkable development. I have come across cases in which people were encouraged to buy\n"
      "in that way, and the professionally qualified doctors and accountants-I suppose even lawyers- who sell various\n"
      "goods on a part-time basis to their clients are earning large amounts of money. That is a complicated matter, \n"
      "and the Bill proposed by my right hon. Friend the Member for Chelsea (Sir N. Scott) is an attempt to put certain\n"
      "matters right. In the late 1960s, when such trading schemes came into being, there was a great deal of demand.\n"
      "There were many abuses, and successive Governments have made attempts to correct those, as the schemes have\n"
      "expanded to include many millions of people.")
print("\nOptions:\n"
      "1: Select Topic\n"
      "2: Search New Member\n"
      "Q: Return to previous Menu")
input("Choice: ")